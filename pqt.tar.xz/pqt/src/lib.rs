pub use aes::{
    cipher::{generic_array::GenericArray, BlockDecrypt, BlockEncrypt, KeyInit},
    Aes256,
};
pub use clap::Parser;
pub use kyber_pke::*;
pub use pqc_kyber::{
    PublicKey, SecretKey, SharedSecret, KYBER_CIPHERTEXTBYTES, KYBER_PUBLICKEYBYTES, KYBER_SSBYTES,
};
pub use rand::{thread_rng, Rng};
pub use sha2::{Digest, Sha512};
pub use std::{fs::*, io::*, net::*, thread};
pub const U64S: usize = std::mem::size_of::<u64>();
pub const SCS: usize = KYBER_CIPHERTEXTBYTES + U64S;
pub const PCS: usize = KYBER_PUBLICKEYBYTES / KYBER_SSBYTES * KYBER_CIPHERTEXTBYTES + U64S;
pub const DHS: usize = 64; //dec hash size
pub const AB: usize = 16;
pub const BUF: usize = 65536;
pub const CH: [u8; 2] = [b'c', b'h']; //tell server
pub const HR: [u8; 2] = [b'h', b'r'];
pub fn aes_key() -> SharedSecret {
    let mut a = [0u8; KYBER_SSBYTES];
    let mut rng = thread_rng();
    for i in &mut a {
        *i = rng.gen()
    }
    a
}
pub fn n() -> SharedSecret {
    let mut nonce = [0u8; KYBER_SSBYTES];
    let mut rng = thread_rng();
    for i in &mut nonce {
        *i = rng.gen()
    }
    nonce
}
pub fn recv_rp(s: &mut TcpStream, old_ls: &SecretKey, rp: &mut PublicKey, aes: &mut SharedSecret) {
    //server
    let mut a = [0u8; PCS];
    s.read_exact(&mut a).unwrap(); //receive client PublicKey
    let d = decrypt(old_ls, a).unwrap();
    rp.copy_from_slice(&d);
    *aes = aes_key();
    let aes = encrypt(rp, aes, n()).unwrap();
    s.write_all(&aes).unwrap(); //send AES key
}
pub fn send_lp(s: &mut TcpStream, rp: &PublicKey, aes: &mut SharedSecret) {
    let old_pair = pke_keypair();
    let (lp, ls) = old_pair;
    let e = encrypt(rp, lp, n()).unwrap();
    s.write_all(&e).unwrap(); //send client PublicKey
    let mut a = [0u8; SCS];
    s.read_exact(&mut a).unwrap(); //receive AES key
    let d = decrypt(ls, a).unwrap();
    aes.copy_from_slice(&d);
}
pub fn aes_dec(aes: &SharedSecret, hash: &[u8], e: &[u8]) -> Vec<u8> {
    let mut h: u8 = 0;
    let key = GenericArray::from(*aes);
    let cipher = Aes256::new(&key);
    let mut d: Vec<u8> = vec![];
    for i in e.chunks(AB) {
        let mut e =
            GenericArray::from(<&[u8] as std::convert::TryInto<[u8; AB]>>::try_into(i).unwrap());
        cipher.decrypt_block(&mut e);
        for j in hash {
            h = h.wrapping_add(*j)
        }
        for j in &mut e {
            *j = (*j).wrapping_sub(h)
        }
        for j in e {
            d.push(j)
        }
    }
    d
}
pub fn aes_enc(aes: &SharedSecret, hash: &[u8], p: &[u8]) -> Vec<u8> {
    let mut h: u8 = 0;
    let key = GenericArray::from(*aes);
    let cipher = Aes256::new(&key);
    let mut e = vec![];
    for i in p.chunks(AB) {
        let mut t = GenericArray::from([0u8; AB]);
        t[..i.len()].copy_from_slice(i);
        for j in hash {
            h = h.wrapping_add(*j)
        }
        for j in &mut t {
            *j = (*j).wrapping_add(h)
        }
        cipher.encrypt_block(&mut t);
        for j in t {
            e.push(j)
        }
    }
    e
}
pub fn ch(s: &mut TcpStream, h: &[u8], aes: &SharedSecret) -> Option<Vec<u8>> {
    let mut a = [0u8; AB];
    s.read_exact(&mut a).unwrap();
    let len = &aes_dec(aes, h, &a)[..U64S]; //get len
    let len = usize::from_le_bytes(len.try_into().unwrap());
    let mut a = vec![0u8; len];
    s.read_exact(&mut a).unwrap();
    let d = &aes_dec(aes, h, &a)[..len]; //get data
    let actual_hash = Sha512::new_with_prefix(d).finalize();
    let e = aes_enc(aes, h, &actual_hash);
    s.write_all(&e).unwrap(); //send hash
    let mut b = [0u8; DHS];
    s.read_exact(&mut b).unwrap(); //get hash reply
    let hash = &aes_dec(aes, h, &b);
    let b = {
        let mut b = true;
        for i in 0..hash.len() {
            if hash[i] != actual_hash[i] {
                b = false;
                break;
            }
        }
        b
    };
    if b {
        Some(d.to_vec())
    } else {
        None
    }
}
pub fn hr(s: &mut TcpStream, h: &[u8], data: &[u8], aes: &SharedSecret) -> Option<()> {
    let len = data.len();
    let len = len.to_le_bytes();
    let mut e = aes_enc(aes, h, &len);
    s.write_all(&e).unwrap(); //send len
    e = aes_enc(aes, h, data);
    s.write_all(&e).unwrap(); //send data
    let hash = Sha512::new_with_prefix(data).finalize();
    let mut a = [0u8; DHS];
    s.read_exact(&mut a).unwrap(); //get hash
    let actual_hash = &aes_dec(aes, h, &a);
    let b = {
        let mut b = true;
        for i in 0..hash.len() {
            if hash[i] != actual_hash[i] {
                b = false;
                break;
            }
        }
        b
    };
    if b {
        e = aes_enc(aes, h, &hash);
        s.write_all(&e).unwrap(); //send hash reply
        Some(())
    } else {
        None
    }
}
pub fn hash(h: &[u8]) -> [u8; DHS] {
    let mut a: [u8; DHS] = Sha512::new_with_prefix(h).finalize().into();
    let mut b = true;
    for i in 0..h.len() {
        if h[i] != a[i] {
            b = false;
            break;
        }
    }
    if b {
        a[0] = a[0].wrapping_add(1)
    }
    a
}
