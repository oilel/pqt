use pqt::*;
#[derive(Parser)]
struct Cli {
    #[arg(short, long)]
    ///Run as "client" or "server"
    r#as: String,
    #[arg(short, long, default_value_t = String::from("127.0.0.1:2250"))]
    bind: String,
    #[arg(short, long)]
    ///where to forward the connections to
    goto: String,
}
fn main() -> Result<()> {
    let args = Cli::parse();
    let listener = TcpListener::bind(args.bind)?;
    let file = "pubkey";
    let mut chaes = [0u8; KYBER_SSBYTES];
    let mut hraes = [0u8; KYBER_SSBYTES];
    let mut rp = [0u8; KYBER_PUBLICKEYBYTES];
    if args.r#as == "server" {
        let old_pair = pke_keypair();
        let (old_lp, old_ls) = old_pair;
        let mut f = OpenOptions::new().write(true).create_new(true).open(file)?;
        f.write_all(&old_lp)?;
        f.flush()?;
        loop {
            if let Ok((mut client, _)) = listener.accept() {
                let goto = args.goto.clone();
                thread::spawn(move || {
                    client.set_nodelay(true).unwrap();
                    recv_rp(&mut client, &old_ls, &mut rp, &mut chaes);
                    let mut proxy = TcpStream::connect(goto).unwrap();
                    proxy.set_nodelay(true).unwrap();
                    let mut h = hash(&chaes);
                    if let Some(d) = ch(&mut client, &h, &chaes) {
                        if d == CH.to_vec() {
                            loop {
                                let d = ch(&mut client, &h, &chaes).unwrap();
                                proxy.write_all(&d).unwrap();
                                h = hash(&h)
                            }
                        } else if d == HR.to_vec() {
                            loop {
                                let mut b = [0u8; BUF];
                                let len = proxy.read(&mut b).unwrap();
                                hr(&mut client, &h, &b[..len], &chaes).unwrap();
                                h = hash(&h)
                            }
                        }
                    }
                });
            }
        }
    } else if args.r#as == "client" {
        let mut f = File::open(file)?;
        f.read_exact(&mut rp)?;
        //
        let mut chs = TcpStream::connect(args.goto.clone())?;
        chs.set_nodelay(true)?;
        send_lp(&mut chs, &rp, &mut chaes);
        let mut chh = hash(&chaes);
        hr(&mut chs, &chh, &CH, &chaes).unwrap();
        //
        let mut hrs = TcpStream::connect(args.goto)?;
        hrs.set_nodelay(true)?;
        send_lp(&mut hrs, &rp, &mut hraes);
        let mut hrh = hash(&hraes);
        hr(&mut hrs, &hrh, &HR, &hraes).unwrap();

        loop {
            if let Ok((mut s, _)) = listener.accept() {
                s.set_nodelay(true)?;
                {
                    let mut s = s.try_clone()?;
                    let mut chs = chs.try_clone()?;
                    thread::spawn(move || {
                        let mut a = [0u8; BUF];
                        loop {
                            let len = s.read(&mut a).unwrap();
                            hr(&mut chs, &chh, &a[..len], &chaes).unwrap();
                            chh = hash(&chh)
                        }
                    });
                }
                {
                    let mut hrs = hrs.try_clone()?;
                    thread::spawn(move || loop {
                        loop {
                            let d = ch(&mut hrs, &hrh, &hraes).unwrap();
                            s.write_all(&d).unwrap();
                            hrh = hash(&hrh)
                        }
                    });
                }
            }
        }
    } else {
        eprintln!(r#"Allowed arguments are "client" or "server""#)
    }
    Ok(())
}
