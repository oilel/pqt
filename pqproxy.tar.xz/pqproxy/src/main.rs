use aes::{
    cipher::{generic_array::GenericArray, BlockDecrypt, BlockEncrypt, KeyInit},
    Aes256,
};
use clap::Parser;
use kyber_pke::*;
use pqc_kyber::{
    PublicKey, SecretKey, SharedSecret, KYBER_CIPHERTEXTBYTES, KYBER_PUBLICKEYBYTES, KYBER_SSBYTES,
};
use rand::{thread_rng, Rng};
use sha2::{Digest, Sha512};
use std::{fs::*, io::*, net::*, thread};
const BUF: usize = 65536;
const U64S: usize = std::mem::size_of::<u64>();
const SCS: usize = KYBER_CIPHERTEXTBYTES + U64S;
const PCS: usize = KYBER_PUBLICKEYBYTES / KYBER_SSBYTES * KYBER_CIPHERTEXTBYTES + U64S;
const DHS: usize = 64; //dec hash size
const AB: usize = 16;
const CH: [u8; 2] = [b'c', b'h']; //tell server
const HR: [u8; 2] = [b'h', b'r'];
#[derive(Parser)]
struct Cli {
    #[arg(short, long)]
    ///Run as "client" or "server"
    r#as: String,
    #[arg(short, long, default_value_t = String::from("127.0.0.1:2250"))]
    bind: String,
    #[arg(short, long)]
    ///where to forward the connections to
    goto: String,
}
fn al(s: &mut TcpStream, a: &mut [u8], l: usize) {
    //assert length
    let mut u: usize = 0;
    while u < l {
        let o = s.read(&mut a[u..]).unwrap();
        u += o;
    }
}
fn aes_key() -> SharedSecret {
    let mut a = [0u8; KYBER_SSBYTES];
    let mut rng = thread_rng();
    for i in &mut a {
        *i = rng.gen()
    }
    a
}
fn n() -> SharedSecret {
    let mut nonce = [0u8; KYBER_SSBYTES];
    let mut rng = thread_rng();
    for i in &mut nonce {
        *i = rng.gen()
    }
    nonce
}
fn recv_rp(s: &mut TcpStream, old_ls: &SecretKey, rp: &mut PublicKey, aes: &mut SharedSecret) {
    //server
    let mut a = [0u8; PCS];
    al(s, &mut a, PCS); //receive client PublicKey
    let d = decrypt(old_ls, a).unwrap();
    rp.copy_from_slice(&d);
    *aes = aes_key();
    let aes = encrypt(rp, &aes, n()).unwrap();
    s.write_all(&aes).unwrap(); //send AES key
}
fn send_lp(s: &mut TcpStream, rp: &PublicKey, aes: &mut SharedSecret) {
    let old_pair = pke_keypair();
    let (lp, ls) = old_pair;
    let mut a = [0u8; PCS];
    let e = encrypt(rp, lp, n()).unwrap();
    s.write_all(&e).unwrap(); //send client PublicKey
    al(s, &mut a, SCS); //receive AES key
    let d = decrypt(ls, &a[..SCS]).unwrap();
    aes.copy_from_slice(&d);
}
fn aes_dec(aes: &SharedSecret, hash: &[u8], e: &[u8]) -> Vec<u8> {
    let mut h: u8 = 0;
    let key = GenericArray::from(*aes);
    let cipher = Aes256::new(&key);
    let mut d: Vec<u8> = vec![];
    for i in e.chunks(AB) {
        let mut e =
            GenericArray::from(<&[u8] as std::convert::TryInto<[u8; AB]>>::try_into(i).unwrap());
        cipher.decrypt_block(&mut e);
        for j in hash {
            h = h.wrapping_add(*j)
        }
        for j in &mut e {
            *j = (*j).wrapping_sub(h)
        }
        for j in e {
            d.push(j)
        }
    }
    d
}
fn aes_enc(aes: &SharedSecret, hash: &[u8], p: &[u8]) -> Vec<u8> {
    let mut h: u8 = 0;
    let key = GenericArray::from(*aes);
    let cipher = Aes256::new(&key);
    let mut e = vec![];
    for i in p.chunks(AB) {
        let mut t = GenericArray::from([0u8; AB]);
        t[..i.len()].copy_from_slice(i);
        for j in hash {
            h = h.wrapping_add(*j)
        }
        for j in &mut t {
            *j = (*j).wrapping_add(h)
        }
        cipher.encrypt_block(&mut t);
        for j in t {
            e.push(j)
        }
    }
    e
}
fn ch(s: &mut TcpStream, h: &[u8], aes: &SharedSecret) -> Option<Vec<u8>> {
    let mut a = vec![0u8; AB];
    al(s, &mut a, AB);
    let len = &aes_dec(aes, h, &a)[..U64S]; //get len
    let len = usize::from_le_bytes(len.try_into().unwrap());
    a = vec![0u8; len];
    al(s, &mut a, len);
    let d = &aes_dec(aes, h, &a)[..len]; //get data
    let actual_hash = Sha512::new_with_prefix(d).finalize();
    let e = aes_enc(aes, h, &actual_hash);
    s.write_all(&e).unwrap(); //send hash
    let mut b = vec![0u8; DHS];
    al(s, &mut b, DHS); //get hash reply
    let hash = &aes_dec(aes, h, &b);
    let b = {
        let mut b = true;
        for i in 0..hash.len() {
            if hash[i] != actual_hash[i] {
                b = false;
                break;
            }
        }
        b
    };
    if b {
        Some(d.to_vec())
    } else {
        None
    }
}
fn hr(s: &mut TcpStream, h: &[u8], data: &[u8], aes: &SharedSecret) -> Option<()> {
    let len = data.len();
    let len = len.to_le_bytes();
    let mut e = aes_enc(aes, h, &len);
    s.write_all(&e).unwrap(); //send len
    e = aes_enc(aes, h, data);
    s.write_all(&e).unwrap(); //send data
    let hash = Sha512::new_with_prefix(data).finalize();
    let mut a = vec![0u8; DHS];
    al(s, &mut a, DHS); //get hash
    let actual_hash = &aes_dec(aes, h, &a);
    let b = {
        let mut b = true;
        for i in 0..hash.len() {
            if hash[i] != actual_hash[i] {
                b = false;
                break;
            }
        }
        b
    };
    if b {
        e = aes_enc(aes, h, &hash);
        s.write_all(&e).unwrap(); //send hash reply
        Some(())
    } else {
        None
    }
}
fn hash(h: &[u8]) -> [u8; DHS] {
    let mut a: [u8; DHS] = Sha512::new_with_prefix(h).finalize().into();
    let mut b = true;
    for i in 0..h.len() {
        if h[i] != a[i] {
            b = false;
            break;
        }
    }
    if b {
        a[0] = a[0].wrapping_add(1)
    }
    a
}
fn main() -> Result<()> {
    let args = Cli::parse();
    let listener = TcpListener::bind(args.bind)?;
    let file = "pubkey";
    let mut chaes = [0u8; KYBER_SSBYTES];
    let mut hraes = [0u8; KYBER_SSBYTES];
    let mut rp = [0u8; KYBER_PUBLICKEYBYTES];
    if args.r#as == "server" {
        let old_pair = pke_keypair();
        let (old_lp, old_ls) = old_pair;
        println!("Exporting to {}", file);
        let mut f = OpenOptions::new().write(true).create_new(true).open(file)?;
        f.write_all(&old_lp)?;
        f.flush()?;
        loop {
            if let Ok((mut client, _)) = listener.accept() {
                let goto = args.goto.clone();
                thread::spawn(move || {
                    client.set_nodelay(true).unwrap();
                    recv_rp(&mut client, &old_ls, &mut rp, &mut chaes);
                    let mut proxy = TcpStream::connect(goto).unwrap();
                    proxy.set_nodelay(true).unwrap();
                    let mut h = hash(&chaes);
                    if let Some(d) = ch(&mut client, &chaes, &chaes) {
                        if d == CH.to_vec() {
                            loop {
                                let d = ch(&mut client, &h, &chaes).unwrap();
                                proxy.write_all(&d).unwrap();
                                h = hash(&h)
                            }
                        } else if d == HR.to_vec() {
                            loop {
                                let mut b = vec![0u8; BUF];
                                let len = proxy.read(&mut b).unwrap();
                                hr(&mut client, &h, &b[..len], &chaes).unwrap();
                                h = hash(&h)
                            }
                        }
                    }
                });
            }
        }
    } else if args.r#as == "client" {
        println!("Importing from {}", file);
        let mut f = File::open(file)?;
        f.read_exact(&mut rp).unwrap();
        //
        let mut chs = TcpStream::connect(args.goto.clone()).unwrap();
        chs.set_nodelay(true).unwrap();
        send_lp(&mut chs, &rp, &mut chaes);
        let mut chh = hash(&chaes);
        hr(&mut chs, &chh, &CH, &chaes).unwrap();
        //
        let mut hrs = TcpStream::connect(args.goto).unwrap();
        hrs.set_nodelay(true).unwrap();
        send_lp(&mut hrs, &rp, &mut hraes);
        let mut hrh = hash(&hraes);
        hr(&mut hrs, &hrh, &HR, &hraes).unwrap();

        loop {
            if let Ok((mut s, _)) = listener.accept() {
                s.set_nodelay(true).unwrap();
                {
                    let mut s = s.try_clone().unwrap();
                    let mut chs = chs.try_clone().unwrap();
                    thread::spawn(move || {
                        let mut a = vec![0u8; BUF];
                        loop {
                            let len = s.read(&mut a).unwrap();
                            hr(&mut chs, &chh, &a[..len], &chaes).unwrap();
                            chh = hash(&chh)
                        }
                    });
                }
                {
                    let mut hrs = hrs.try_clone().unwrap();
                    thread::spawn(move || loop {
                        loop {
                            let d = ch(&mut hrs, &hrh, &hraes).unwrap();
                            s.write_all(&d).unwrap();
                            hrh = hash(&hrh)
                        }
                    });
                }
            }
        }
    } else {
        eprintln!(r#"Allowed arguments are "client" or "server""#)
    }
    Ok(())
}
